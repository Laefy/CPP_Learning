#include <iostream>

int main(int argc, char** argv)
{
    std::cout << "Hello!" << std::endl;
    return 0;
}